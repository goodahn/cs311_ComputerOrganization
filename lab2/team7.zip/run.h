/***************************************************************/
/*                                                             */
/*   MIPS-32 Instruction Level Simulator                       */
/*                                                             */
/*   CS311 KAIST                                               */
/*   run.h                                                     */
/*                                                             */
/***************************************************************/

#ifndef _RUN_H_
#define _RUN_H_

#include <stdio.h>

#include "util.h"
/* functions */
void		process_instruction();

#endif
